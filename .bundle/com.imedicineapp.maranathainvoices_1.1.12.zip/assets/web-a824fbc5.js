import{br as n}from"./index-1b47be4f.js";class m extends n{async scanDocument(e){throw console.log(e),this.unimplemented("Not implemented on web.")}}export{m as DocumentScannerWeb};
