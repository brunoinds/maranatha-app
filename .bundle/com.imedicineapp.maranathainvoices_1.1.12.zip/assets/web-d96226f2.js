import{br as n}from"./index-1b47be4f.js";class o extends n{async show(e){}async hide(e){}}export{o as SplashScreenWeb};
